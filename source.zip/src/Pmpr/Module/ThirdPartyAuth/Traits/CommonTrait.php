<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051798e69e7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Traits; use Pmpr\Module\ThirdPartyAuth\Provider\Provider; trait CommonTrait { public function ggmimqeymoegueqg(string $iwigiqwyskocowwo) : string { $ieokeoyugcmwuumq = trailingslashit($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ieokeoyugcmwuumq()); if ($this->caokeucsksukesyo()->eiwcuqigayigimak()->ewswusimyeosaogm()) { goto qqewoyookaskiuek; } $iewmcsieaqyamggu = $this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->yqymaqmqiqmmmsoo([Provider::cuwqkowuwgeysoqm => $iwigiqwyskocowwo], $ieokeoyugcmwuumq); goto ssoucoucsgccekwe; qqewoyookaskiuek: $iewmcsieaqyamggu = trailingslashit($ieokeoyugcmwuumq . Provider::cuwqkowuwgeysoqm) . $iwigiqwyskocowwo; ssoucoucsgccekwe: return $iewmcsieaqyamggu; } }
