<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6819d6011b6c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Traits; use Pmpr\Module\ThirdPartyAuth\Provider\Provider; trait CommonTrait { public function ggmimqeymoegueqg(string $iwigiqwyskocowwo) : string { $ieokeoyugcmwuumq = trailingslashit($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ieokeoyugcmwuumq()); if ($this->caokeucsksukesyo()->eiwcuqigayigimak()->ewswusimyeosaogm()) { $iewmcsieaqyamggu = trailingslashit($ieokeoyugcmwuumq . Provider::cuwqkowuwgeysoqm) . $iwigiqwyskocowwo; } else { $iewmcsieaqyamggu = $this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->yqymaqmqiqmmmsoo([Provider::cuwqkowuwgeysoqm => $iwigiqwyskocowwo], $ieokeoyugcmwuumq); } return $iewmcsieaqyamggu; } }
