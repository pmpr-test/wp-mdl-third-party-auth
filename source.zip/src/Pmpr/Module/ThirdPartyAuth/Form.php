<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ac859731ed4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\ThirdPartyAuth\Provider\Provider; class Form extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('login_form', [$this, 'ciuaeosmuwakscyy']); } public function ciuaeosmuwakscyy() { if ($ukiskwsmqscwauuu = Provider::symcgieuakksimmu()->vomyocgeymkomqqm()) { $qqscaoyqikuyeoaw = $this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->wweuwcaqkkowawsy() ? 'wp-login' : 'frontend'; $this->iuygowkemiiwqmiw($qqscaoyqikuyeoaw, [Constants::qwumqqyuasyskkkc => $ukiskwsmqscwauuu, Constants::oomaageiyqkaiekk => $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw()->ewgquygaowykwacc(Provider::wqcswcwygsiiauqw, Provider::gcouqeuuoimiuqoc, false, false)], [Constants::qaacaqioeyiuakeu => true]); } } }
