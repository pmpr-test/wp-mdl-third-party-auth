<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7ca7d0cc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Model; use Pmpr\Module\ThirdPartyAuth\Container; class Model extends Container { public function aqyikqugcomoqqqi() { UserLink::symcgieuakksimmu(); } }
