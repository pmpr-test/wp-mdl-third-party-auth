<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ac263c6df9d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Provider\Yahoo; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\ThirdPartyAuth\Provider\Common; class Yahoo extends Common { public function __construct() { $this->name = Constants::oowokkckywyoauyu; $this->api = API::symcgieuakksimmu($this->aakmagwggmkoiiyu()); parent::__construct(); } }
