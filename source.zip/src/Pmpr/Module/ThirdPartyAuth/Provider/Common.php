<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7ca7d0cc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Provider; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\ThirdPartyAuth\Container; abstract class Common extends Container { protected ?API $api = null; protected ?string $name = null; public function auamgqiwisysomsa() : ?API { return $this->api; } public function aakmagwggmkoiiyu() : ?string { return $this->name; } public function gesoiqwieuaqaaqw() : string { $gqusacuooiagkuom = $this->uwkmaywceaaaigwo()->giiecckwoyiawoyy(); return $this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->yqymaqmqiqmmmsoo([Constants::ugqacsomqcgmoqug => Provider::asiscgcuqkseseew, Constants::wssmqksaywiuskki => $this->aakmagwggmkoiiyu(), Provider::gcouqeuuoimiuqoc => $gqusacuooiagkuom->ikkqcccaweckukug(Provider::wqcswcwygsiiauqw)], $gqusacuooiagkuom->ieokeoyugcmwuumq()); } }
