<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6817494f1d8ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Panel; use Pmpr\Module\Panel\AbstractPanel; class Panel extends AbstractPanel { public function gigwcakmiyayoigw() { } }
