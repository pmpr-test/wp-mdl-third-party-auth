<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169e2db6972             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Panel; use Pmpr\Module\Panel\AbstractPanel; class Panel extends AbstractPanel { public function gigwcakmiyayoigw() { } }
