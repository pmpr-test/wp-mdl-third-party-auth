<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68174ddee6a8a             |
    |_______________________________________|
*/
 use Pmpr\Module\ThirdPartyAuth\ThirdPartyAuth; ThirdPartyAuth::symcgieuakksimmu();
