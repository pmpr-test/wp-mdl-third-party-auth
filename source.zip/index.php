<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             682fc591008d5             |
    |_______________________________________|
*/
 use Pmpr\Module\ThirdPartyAuth\ThirdPartyAuth; ThirdPartyAuth::symcgieuakksimmu();
